import { ChangeDetectorRef, Component, ElementRef, NgZone, OnChanges, OnInit, TemplateRef, ViewChild, viewChildren } from '@angular/core';
import { AudioRecordingService } from '../../services/audio-recording.service';
import { HttpService } from '../../services/http.services';
import { BsModalRef, BsModalService, ModalModule } from 'ngx-bootstrap/modal';
import { CommonModule } from '@angular/common';
import { environment } from '../../../environment/environment';
import { Router } from '@angular/router';
import { AudioSocketsService } from '../../services/audio-sockets.service';
import * as RecordRTC from 'recordrtc';
import { Init } from 'v8';
import { Observable, interval } from 'rxjs';

declare var webkitSpeechRecognition: any
declare var window: Window & typeof globalThis;
@Component({
    selector: 'app-recording',
    standalone: true,
    imports: [CommonModule, ModalModule],
    templateUrl: './recording.component.html',
    styleUrl: './recording.component.scss'
})

export class RecordingComponent {
    audioData:any;
    transcribed:any[]=  [];
    completeTranscribe:any="";
    recordingStatus: boolean = false;
    isRecording = false;
    audioURL: string | null = null;
    jsonStr: any = "";
    start!: any;
    startTime!:any
    end!: any;
    fileToUpload!: any;
    isLoading: boolean = false;
    audioSrc!: any
    response: any;
    @ViewChild('audioPlayer') audioPlayer!: ElementRef<HTMLAudioElement>;
    @ViewChild('player') player!: ElementRef<HTMLAudioElement>;

    constructor(private audioRecordingService: AudioRecordingService, private cd: ChangeDetectorRef,
        private http: HttpService, private router: Router, private ngZone: NgZone,
        private audioSocketService:AudioSocketsService
    ) {

    }

    ngOnInit() {
        
        this.audioSocketService.connectSocket();
        this.audioRecordingService.audioBlob$.subscribe(blob => {
            this.audioURL = window.URL.createObjectURL(blob);
            this.audioPlayer.nativeElement.src = this.audioURL;
            this.audioSrc = this.audioPlayer;
            this.cd.detectChanges();
        });
        this.audioRecordingService.transcribeDataChange.subscribe(res=>{
            if(res!=this.transcribed[this.transcribed.length-1] && res!='error'){
                this.transcribed.push(res);
            }
        });
        this.audioRecordingService.blobChange.subscribe(res=>{
            this.http.gettranscript(res).subscribe(message=>{
                console.log(message);
              });
            
        })
        this.audioRecordingService.transcribeCompleteData.subscribe(res=>{
            if(this.completeTranscribe!=res && res !='error')
            {
                this.completeTranscribe=res;
                const transferObject={
                    transcript: this.completeTranscribe,
                    ROS:" ",
                    consultation_type :""
                }
                //let jf=JSON.stringify(transferObject);
                this.completeTranscribe=res;
                this.isLoading=false;
                this.http.getSummary(transferObject)
                .subscribe(result=>{
                    console.log(result)
                this.audioRecordingService.setEHRChange(result.notes);
                this.response = result.notes;
                this.isLoading = false;

                });
            }
            
        });
    }
    handleFileInput(event: any) {
        let duration = 0;
        this.fileToUpload = event.target.files[0];
        this.onUploadBlob(this.fileToUpload, duration,new Date().toISOString(),new Date().toISOString());
    }

    startStopRecording() {
        this.transcribed=[];
        var txt =
            "Hello " +
            //"patientName" +
            ". Our bot will be taking notes during this session to help us make sure we don’t miss any important details for the documentation purpose. this encounter will now be recorded. ";
        var utterance = new SpeechSynthesisUtterance(txt);
        window.speechSynthesis.cancel();
        (<any>window).speechSynthesis.speak(utterance);
        setTimeout(() => {
            this.startRecording();
        }, 12000);
        
    }
    startRecording() {
        this.isRecording = true;
        this.start = Date.now();
        this.startTime= new Date().toISOString();
        this.audioRecordingService.startRecording();
        console.log("start method=========");
    }
    stopRecording() {
        this.isRecording = false;
        let audioLength = Date.now() - this.start;
        this.audioRecordingService.stopRecording(audioLength);
        audioLength = audioLength / 1000;
        console.log(this.start);
        console.log("audioLength = ", audioLength);
        this.audioRecordingService.audioBlob$.subscribe(blob => {
            this.onUploadBlob(blob, audioLength,this.startTime,new Date().toISOString());
        });
    }

    onUploadBlob(blob: Blob, audioLength: number,startTime:any,endTime:any) {
        this.isLoading = true;
        const formblob = new FormData();
        formblob.append("files", blob)
        this.http.post(environment.UploadBlob, formblob).subscribe((result: any) => {
            console.log("blob Result", result);
            const tableData = {
                partitionKey: "20b65520-5337-4f0d-a047-7a70f579082f",
                rowKey:result.fileName,
                recordingBlobPath: "https://rsiehrstorage.blob.core.windows.net/ehraudio/" + result.fileName + ".wav",
                eTag: result.response.value.eTag,
                encounterType:"General",
                patientContext:"Test User",
                consultationStartDateTime:startTime,
                consultationEndDateTime:endTime
            }
            this.onSubmitPatientEncounter(blob, tableData, audioLength);
        });
    }
    onSubmitPatientEncounter(blob: Blob, value: any, audioLength: number) {
        this.http.post(environment.AddPatientEncounter, value).subscribe((result: any) => {
            console.log("table Result", result);
            this.setAudioURL(blob);
            this.onMLCall(blob, audioLength);
        });
    }

    onMLCall(blob: Blob, audioLength: number) {
        const formData = new FormData();
        formData.append("audiofile", blob);
        if (!this.jsonStr) {
            this.jsonStr = '{"Type":"General","Reported_Issues":""}';
        }
        this.jsonStr = { ...JSON.parse(this.jsonStr), audio_length: audioLength };
        console.log("ros JSON = ", this.jsonStr);
        const blobFile = new Blob([JSON.stringify(this.jsonStr)], {
            type: "application/json;charset=utf-8",
        });
        console.log("calling api now...............");
        formData.append("jsonfile", blobFile);
        this.http.postML(environment.MLSummary, formData).subscribe((result) => {
            this.audioRecordingService.setEHRChange(result);
            this.response = result;
            this.isLoading = false;
            this.setAudioURL(blob);
        });
    }

    Next() {
        console.log(this.response);
        this.ngZone.run(() => this.router.navigate(['/problemDetail']))
    }

    setAudioURL(blob: Blob) {
        this.audioURL = window.URL.createObjectURL(blob);
        this.audioSrc = this.audioURL;
        this.cd.detectChanges();
    }
    ngOnDestroy(){
      this.audioSocketService.disconnectSocket();
    }

}
