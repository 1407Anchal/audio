import { Component,OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ProblemDetailService } from '../problem-detail.service';
import exportFromJSON from 'export-from-json';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { AudioRecordingService } from '../services/audio-recording.service';
import { ActivatedRoute } from '@angular/router';
import { PatientEncounterDetail } from '../interface/patientEncounterDetail';


interface JSON{
  updatedjson:string;
}

interface Tab {
  title: string;
}

@Component({
  selector: 'app-problemdetail',
  templateUrl: './problemdetail.component.html',
  providers:[ProblemDetailService],
  standalone: true,
  imports: [CommonModule,FormsModule,HttpClientModule],
  styleUrl: './problemdetail.component.scss'
})
export class ProblemdetailComponent implements OnInit {
  data:any = [{ foo: 'foo'}, { bar: 'bar' }];
fileName : string = 'download';
exportType =  exportFromJSON.types.json;
receivedData: any;
advisory:any;
advisoryForEdit:any;
icdCodes:any;
newSummary:any;
summary:any;
patient : PatientEncounterDetail={
    PartitionKey:"",
      RowKey:"",
      Timestamp: new Date,
      ETag: "",
      RecordingBlobPath: "",
      ConsultationStartDateTime: new Date,
      ConsultationEndDateTime:new Date,
      OriginalJson: "",
      UpdatedJson: ""
};


ngOnInit(): void {
  
}

tempJson = {
  "advisory": [
    "- Drink adequate fluids, especially when having a fever",
    "- Eat soft and sugary foods for energy",
    "- Get enough rest",
    "- Wash hands frequently and avoid close contact with others when sick",
    "- Avoid greasy foods when sick"
  ],
  "new_summary": {
    "Appointments": [
      "- Follow up if not better or if questions arise"
    ],
    "Assessment": [
      "- Patient is likely experiencing a viral infection",
      "- Mild dehydration due to inadequate fluid intake",
      "- Suggestion to eat soft and sugary foods for energy"
    ],
    "CPT Codes": [
      "Consultation Duration: 99203"
    ],
    "Chief complaint": [
      "- Fever since last two days",
      "- Body ache"
    ],
    "History of present illness": [
      "- Onset: 2 days ago",
      "- Duration: 2 days",
      "- Key symptoms: fever (fluctuating between 99-101), body ache, nausea, loss of appetite, bulging sensation in the stomach",
      "- Notable changes: fever fluctuates after taking paracetamol"
    ],
    "ICD Codes": [
      "- PRIMARY:-",
      "- R50.9: Fever, unspecified.",
      "-",
      "- SUGGESTIVE:-",
      "- R53.83: Other fatigue.",
      "- R63.0: Anorexia.",
      "- R11.0: Nausea.",
      "- Z71.89: Other specified counseling, not elsewhere classified (pertaining to the recommendation for primary care and routine health maintenance).",
      "ROS:",
      "- No additional information from ROS can be factored into the Assessment as there is no mention of eye symptoms in the main text."
    ],
    "Plan": [
      "- Drink more fluids, at least 6-8 glasses per day and an extra glass when having a fever",
      "- Eat soft and sugary foods for energy",
      "- Recommended foods: rice, kichidi, soups, broths, jello water, plain toasts",
      "- Take Tylenol every 4-6 hours",
      "- Follow up if not better, or if any questions arise",
      "- No blood tests required at the moment, but suggested to establish a regular primary care for routine blood work and other concerns"
    ],
    "Prescription": [
      "- Tylenol every 4-6 hours"
    ],
    "Vitals": [
      "- No temperature"
    ]
  },
  "summary": {
    "Assessment": "- Suspected viral fever with associated body aches and gastrointestinal discomfort.\n- Mild dehydration likely due to insufficient fluid intake.",
    "CPT Codes": [
      "Consultation Duration: 99203"
    ],
    "ICD Codes": [
      "- PRIMARY:-",
      "- R50.9: Fever, unspecified.",
      "-",
      "- SUGGESTIVE:-",
      "- R53.83: Other fatigue.",
      "- R63.0: Anorexia.",
      "- R11.0: Nausea.",
      "- Z71.89: Other specified counseling, not elsewhere classified (pertaining to the recommendation for primary care and routine health maintenance).",
      "ROS:",
      "- No additional information from ROS can be factored into the Assessment as there is no mention of eye symptoms in the main text."
    ],
    "Objective": "- Physical examination reveals normal vital signs and no temperature.\n- HEENT (head, eyes, ears, nose, throat) exam is negative.\n- Heart and lung exams show no abnormalities.\n- Abdominal exam is negative with normal bowel sounds, no pain, discomfort, guarding, or rigidity.\n- The skin appears normal, not indicative of dehydration.",
    "Plan": "- Encourage increased fluid intake, aiming for at least 6 to 8 glasses per day, plus an extra glass to account for fever-induced dehydration.\n- Advised to consume soft foods and sugary foods for energy, avoiding greasy foods.\n- Recommended to continue taking Tylenol every 4 to 6 hours for fever management.\n- No blood tests suggested at this stage due to the presumed simplicity of the viral infection.\n- Follow-up communication through the patient portal encouraged, and a suggestion to establish regular primary care for routine health maintenance.",
    "Subjective": "- The patient reports a fever for the last two days with fluctuating temperatures between 99 to 101 degrees Fahrenheit.\n- Body aches are present; experiences nausea when lying down and a sensation of stomach bloating.\n- The patient has a decreased appetite and reduced food intake but has been consuming fluids, specifically around 2 to 3 ounces of lemonade.\n- Sleep patterns may be affected due to the illness, although not explicitly stated.\n- No recent travel or known contact with sick individuals."
  }
};

  constructor(private route: ActivatedRoute, private dataService : ProblemDetailService,private audioRecordingService: AudioRecordingService){
   this.receivedData = this.audioRecordingService.getJsonData();
   if(this.receivedData == undefined){
    this.advisory=[
      "- Drink plenty of fluids.",
      "- Get adequate rest.",
      "- Avoid strenuous activities.",
      "- Monitor temperature regularly.",
      "- If symptoms persist, seek medical attention."
  ];

    this.summary={
      "Assessment": "- Potential diagnosis of mild fever based on the patient's reported temperature.\n- Insufficient data to identify contributing factors or complications without further information.",
      "CPT Codes": [
          "Consultation Duration: 99202"
      ],
      "ICD Codes": [
          "- PRIMARY:",
          "- R50.9: Fever, unspecified.",
          "- SUGGESTIVE:",
          "- Additional codes cannot be suggested without more specific information on symptoms or underlying conditions."
      ],
      "Objective": "- Fever confirmed with a patient-reported temperature of 99.5°F.\n- No physical examination results or observable signs provided.",
      "Plan": "- Healthcare provider suggests medication to address the fever.\n- No follow-up appointments or additional steps mentioned in the provided text.",
      "Subjective": "- Patient reports not feeling well and suspects a fever.\n- Patient mentions a specific temperature of 99.5 degrees Fahrenheit.\n- No additional personal or medical history provided."
  };
    this.newSummary={
      "Appointments": [
          "- No upcoming appointments mentioned."
      ],
      "Assessment": [
          "- No formal assessment or evaluation provided."
      ],
      "CPT Codes": [
          "Consultation Duration: 99202"
      ],
      "Chief complaint": [
          "- Patient reports feeling unwell and suspects having a fever."
      ],
      "History of present illness": [
          "- Onset and duration of illness not mentioned.",
          "- Key symptom is a fever with a temperature of 99.5."
      ],
      "ICD Codes": [
          "- PRIMARY:",
          "- R50.9: Fever, unspecified.",
          "- SUGGESTIVE:",
          "- Additional codes cannot be suggested without more specific information on symptoms or underlying conditions."
      ],
      "Plan": [
          "- Prescribed medication for the fever.",
          "- No other management strategies or follow-up care instructions provided."
      ],
      "Prescription": [
          "- Medication prescribed, details not provided."
      ],
      "Vitals": [
          "- Temperature of 99.5 reported."
      ]
  };
  this.selectedTab = "Soap Notes"; 

   }
   else{
   this.advisory=this.receivedData["advisory"];
   this.summary=this.receivedData["summary"];
   this.newSummary=this.receivedData["new_summary"];
   this.selectedTab = "Soap Notes"; 
   this.saveJson();
   }
   for(let i=0;i<this.advisory.length;i++){
    this.advisory[i]=this.advisory[i].replace("- ","");
    }
    this.advisoryForEdit=this.advisory.join('\n');  
    this.summary.Subjective=this.summary.Subjective.replaceAll("- ","");
    this.summary.Assessment=this.summary.Assessment.replaceAll("- ","");
    this.summary.Objective=this.summary.Objective.replaceAll("- ","");
    this.summary.Plan=this.summary.Plan.replaceAll("- ","");
    this.summary.Subjective=this.summary.Subjective.replaceAll("- ","");
    this.icdCodes=this.summary["ICD Codes"];
     for(let i=0;i<this.summary["ICD Codes"].length;i++){
      this.summary["ICD Codes"][i]=this.summary["ICD Codes"][i].replace("- ","");
    }
    this.icdCodes=this.summary["ICD Codes"].join('\n')
    this.selectedTab = "Soap Notes"; 

  }
  
saveJson(){  
  this.patient.OriginalJson = JSON.stringify(this.receivedData);
  this.dataService.saveData(this.patient).subscribe(
    (items: any) => {
      this.patient.RowKey=items.rowKey;
      this.patient.PartitionKey=items.partitionKey;
    },
    error => {
      console.log('Error fetching data:', error);
    }
  );
}

  tabs = [
    { title: 'Detailed Report' },
     { title: 'Soap Notes' },
     { title: 'Clinical Notes' }
  ];
  selectedTab: any;

  selectTab(tab:any) {
    this.selectedTab = tab.title;
  }
  submit(){
    this.patient.UpdatedJson = JSON.stringify(this.receivedData);
    this.dataService.updateData(this.patient).subscribe(
      (items: any) => {
      },
      error => {
        console.log('Error fetching data:', error);
      }
    );
  }
  exportJSON(){
  exportFromJSON({
    data: this.receivedData,
    fileName: 'data_export',
    exportType: 'json' // or 'json' or 'xls'
  });
}

generatePDF(element: HTMLElement) {
  
  //this.generatePDFs(this.tempJson);
  const htmlContent = element;
  const doc = new jsPDF();
  doc.html(htmlContent, {
    callback: (pdf) => {
      pdf.save('generated.pdf');
    },
    x: 15,
    y: 15,
    width: 170, //target width in the PDF document
    windowWidth: 650 
  });
}

generatePDFs(data: any) {
  const doc = new jsPDF();
  let yPos = 10;

  // Loop through each key in the JSON data
  Object.keys(data).forEach((key) => {
    const value = data[key];

    // Add key and value to the PDF
    doc.text(`${key}: ${JSON.stringify(value)}`, 10, yPos);
    yPos += 10;

    // If value is an array, add each item on a new line
    if (Array.isArray(value)) {
      value.forEach((item) => {
        doc.text(`- ${JSON.stringify(item)}`, 20, yPos);
        yPos += 10;
      });
    }
  });

  doc.save('data.pdf');
}

}

