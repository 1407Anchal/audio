export interface IWindow extends Window  {
    webkitSpeechRecognition: any;
    SpeechSynthesisUtterance:any;
  }