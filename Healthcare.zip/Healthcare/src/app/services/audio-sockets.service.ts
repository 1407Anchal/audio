import { Injectable, NgModule } from '@angular/core';
// import * as signalR from '@aspnet/signalr';
import { Observable } from 'rxjs';
import { Socket, SocketIoConfig, SocketIoModule } from 'ngx-socket-io';
import * as pako from 'pako';

const config:SocketIoConfig = {url:'http://localhost:5000',options :{}};


@Injectable({
  providedIn: 'root'
})

export class AudioSocketsService extends Socket{
  
  constructor() {
    super(config);
  }
  
  connectSocket(){
    super.on('connect',()=>{
      console.log("Connect to Server");
    })
  }
    disconnectSocket(){
    super.on('disconnect',()=>{
      console.log("DisConnect to Server");
    })

  }
  sendMessage(data:any, audioIternation:number) {
  //   this.socket.emit('message',data);
    const reader = new FileReader();
    reader.onloadend = () => {
      const arrayBuffer = reader.result as ArrayBuffer;
    
      const byteArray = new Uint8Array(arrayBuffer);
      super.emit('message',{data:byteArray,iteration:audioIternation});
      console.log("iteration number:==",audioIternation);
    };
    reader.readAsArrayBuffer(data);
    return super.fromEvent('message');
    
  }

  getMessage() {
    return super.fromEvent('message');
  }
}
