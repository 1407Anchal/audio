import { Injectable } from '@angular/core';
import { BehaviorSubject, Subject, Subscription, takeUntil, timestamp } from 'rxjs';
import { bufferToWave } from '../helper/audio-helper';
import { AudioSocketsService } from './audio-sockets.service';
import recordRTC from 'recordrtc';
import * as RecordRTC from 'recordrtc';
import { HttpService } from './http.services';
import { arrayBuffer } from 'stream/consumers';

@Injectable({
  providedIn: 'root'
})
export class AudioRecordingService {
  audioIteration : number = 0;
  sendInterval:any;
  transcribedData:any;
  record:any;
  record2:any;
  blobUrl:any;
  isRecord:boolean=false;
  stream:any;
  stream2:any;
  isSilence:boolean=false;
  isStop:boolean=false;
  silenceStart:any;
  completeAudio:any[]=[];
  audioTranscribeCompleted:any=false;
  //transcribeMessage:any[]=[];


  transcribeDataChange: Subject<string> = new Subject<string>();
  transcribeCompleteData: Subject<string> = new Subject<string>();
  blobChange: Subject<any> = new Subject<any>();
  audioLength: any;
  constructor(private audioSocketService:AudioSocketsService) {
  }
  private audioBlobSubject = new Subject<Blob>();
  private ehrJsonSubject=new BehaviorSubject<any>(null);
  private jsonData: any;

  audioBlob$ = this.audioBlobSubject.asObservable();
  ehrJson$=this.ehrJsonSubject.asObservable();

  async startRecording() {
    console.log("start method=========");
    this.isRecord = true;
    this.isSilence = true;
    this.audioIteration=0;
    this.isStop=false;
    let mediaConstraints = {
      video:false,
      audio:true
    };

    navigator.mediaDevices.getUserMedia(mediaConstraints).then(this.successCallback.bind(this),this.errorCallback.bind(this));
    
  }

  successCallback(stream:any){
    if(!this.isStop && !this.record){
      var options:any = {
        mimeType: 'audio/wav',
        numberOfAudioChannels: 1,
        sampleRate: 44100,
        bufferSize: 4096,
        recorderType:recordRTC.StereoAudioRecorder,
        timeSlice:10000, //in milliseconds
        ondataavailable:(blob:Blob) =>{
          this.audioIteration = this.audioIteration + 1;
          this.completeAudio.push(blob);
          
          this.sendAudioChunks(blob);
        }
      
      };
        this.record = new recordRTC.StereoAudioRecorder(stream, options);
        this.record.record();
        this.stream = stream;
      
    }
    else{
      if (stream) {
            stream.getAudioTracks().forEach((track:any) => track.stop());
            stream = null;
          }
    }
  }

  async processRecord(blob:any){
    this.audioIteration = this.audioIteration + 1;
    // let rr=await blob.arrayBuffer();
    //   let textDecoder = new TextDecoder();
    //   let ff=textDecoder.decode(rr);
    // this.blobChange.next(ff);
      let arrayBuffer= await blob.arrayBuffer();
      let obj ={}
      const byteArray = new Uint8Array(arrayBuffer);
   
      const STRING_CHAR = byteArray.reduce((data, byte)=> {
        return data + String.fromCharCode(byte);
        }, '');
   
   
     
      const base64String = btoa(STRING_CHAR)
      obj = {
        'blob': base64String,
        'iteration':this.audioIteration
      }
      this.blobChange.next(obj);
    


    // const fr = new FileReader();
    // fr.onload = function(event:any) {
    //   let arrayBuffer = event.target.result;
  
    //   const byteArray = new Uint8Array(arrayBuffer);
 
    //   let textDecoder = new TextDecoder();
    //   let ff=textDecoder.decode(arrayBuffer);
    // }

		// fr.readAsText(blob);

    await setTimeout(() => {
      console.log('sleep');
      this.sendAudioChunks(blob);

      this.audioTranscribeCompleted=true;
    }, 15000);
    
    this.audioBlobSubject.next(blob);
  }

  errorCallback(error:any){
    console.log("error:==",error);
  }
 
  async sendAudioChunks(audioChunks:any){ 
    console.log("proceess going-"+this.audioIteration);
    
    let subscribion:Subscription
        subscribion=this.audioSocketService.sendMessage(audioChunks,this.audioIteration).subscribe((message:any)=>{
        console.log("response from server after silence detect:==",message);
        if(!this.audioTranscribeCompleted){
          this.transcribeDataChange.next(message);
        }
        else{
          this.transcribeCompleteData.next(message);
        }

      })
  }

   stopRecording(audio_length:any) {
    this.audioLength=audio_length;
    this.isStop = true;
    this.record.stop(this.processRecord.bind(this));
    this.record = null;
    if (this.stream) {
      this.stream.getAudioTracks().forEach((track:any) => track.stop());
      this.stream = null;
    }
  }

  setEHRChange(value:any){
      this.jsonData = value;
    this.ehrJsonSubject.next(value);
  }

  getJsonData(): any {
    return this.jsonData;
  }
}