import { TestBed } from '@angular/core/testing';

import { AudioSocketsService } from './audio-sockets.service';

describe('AudioSocketsService', () => {
  let service: AudioSocketsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AudioSocketsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
