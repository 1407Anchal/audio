import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class HttpService {
  actionUrl: string = 'http://localhost:5088/api/';
  mlActionUrl: string = 'http://10.131.85.58:5053/';
  private audioSummaryUrl = 'http://127.0.0.1:6783/';
  private transcribeUrl = 'http://localhost:7071/api/AudioToTranscribe';
  constructor(private http: HttpClient) {

  }
  public getAll<T>(apiUrl: string): Observable<T> {
    return this.http.get<T>(this.actionUrl + apiUrl);
  }

  public post<T>(apiUrl: string, data: T): Observable<T> {
    return this.http.post<T>(this.actionUrl + apiUrl, data);
  }
  public postML<T>(apiUrl: string, data: T): Observable<T> {
    return this.http.post<T>(this.mlActionUrl + apiUrl, data);
  }
  

  getSummary(data: any): Observable<any> {
    console.log(data);
    return this.http.post<any>(this.audioSummaryUrl+'process_data',data);
  }
  gettranscript(data: any): Observable<any> {
    console.log(data);
    const headers = new HttpHeaders({
      'Content-Type':'application/json'
    })
    return this.http.post<any>(this.transcribeUrl,data,{headers:headers});
  }
  
}
