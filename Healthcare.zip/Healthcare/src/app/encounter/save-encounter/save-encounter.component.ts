import { Component } from '@angular/core';

@Component({
  selector: 'app-save-encounter',
  standalone: true,
  imports: [],
  templateUrl: './save-encounter.component.html',
  styleUrl: './save-encounter.component.scss'
})
export class SaveEncounterComponent {

}
