export const environment = {

  BlobPath:"https://rsiehrstorage.blob.core.windows.net/ehraudio/",
  // API URL

  UploadBlob: 'AzureBlob/UploadBlobs',
  AddPatientEncounter:'PatientEncounterDetail/AddPatientEncounter',
  MLSummary:'extract_summary'
}
